# Real Golf Token DApp

This is a simple frontend for interacting with the Real Golf Token (RGT) deployed on Polygon Mumbai.

## Instructions

1. Upload this repo to a GitHub repository (e.g., `real-golf-token-dapp`)
2. Go to Repository > Settings > Pages
3. Set source to `main` branch, `/root`
4. Your site will appear at: `https://yourusername.github.io/real-golf-token-dapp`

Test it on MetaMask Mobile or any web3-enabled browser.
